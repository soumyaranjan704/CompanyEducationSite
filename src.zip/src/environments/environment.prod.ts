export const environment = {
  production: true,
  signUpBaseUrl:'http://localhost:8080/signup',
  contactUsBaseUrl:'http://localhost:8080/contact',
  getNewsLetter:'http://localhost:8080/newsletter',
  getPostJob:'http://localhost:8080/postJobData',
  uploadCVBaseUrl:'http://localhost:8080/apply'

};
