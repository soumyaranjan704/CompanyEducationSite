import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullstack',
  templateUrl: './fullstack.component.html',
  styleUrls: ['./fullstack.component.scss']
})
export class FullstackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
