import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UploadCVForm } from 'src/app/form-data-advance';
import { UtilityService } from 'src/app/services/utility.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-cvupload',
  templateUrl: './cvupload.component.html',
  styleUrls: ['./cvupload.component.scss']
})
export class CvuploadComponent implements OnInit {
  uploadCVDetails = new UploadCVForm();

  constructor(private utilityService: UtilityService) { }

  ngOnInit(): void {
  }

  uploadNewCV(form: NgForm) {
    let url = environment.uploadCVBaseUrl;
    let requestModel = form.value;
    console.log(form.value);
    let contactRef =  document.getElementById("signUpForm")  as HTMLFormElement;
    contactRef.reset();
    this.utilityService.postDataToService(url, requestModel).subscribe(data => {
    
      console.log("Success");
    }, error => {
      console.log("Error");
    });
  
  }
}
