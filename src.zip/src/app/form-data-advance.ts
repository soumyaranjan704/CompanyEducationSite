export class SignupForm{    
    public firstname: string;
    public lastname: string;
    public email: string;
    public mobile: string;
    public branch: string;
    public date: string;

    public specialization: string;
    public year: string;

   
    }


    export class ContactUsForm{
        public name: string;
        public company: string;
        public email: string;
        public phone: string;
        public message: string;


    }

    export class UploadCVForm{
        public fullname: string;
        public email: string;
        public file: string;

    }